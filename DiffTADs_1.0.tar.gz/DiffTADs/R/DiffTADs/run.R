#TADs prediction for single context

rm(list=ls())
setwd("E:/TADs/DiffTADs")
source("loadmat.R")
source("submatrix.R")
source("TADsda.R")

dirin <- "E:/TADs/HTADsPre/normdata/GM12878/chr1/50k/ICE"
CPMnormatlist <- loadmat(dirin1=dirin, dirin2=NULL)

CPMnormatlist <- lapply(CPMnormatlist$listcon1, submatrix, species="hg19", chr="chr1",start=20000000,end=40000000, resolution=50000)

parFTRLreg=list(repeatnum=5, iteration=2, lambda=0.1, alpha=c(0.0025,0.005,0.010), beta=c(1), l1=c(1), l2=c(1))

output <- TADsda(matlistcon1=CPMnormatlist, matlistcon2=NULL, namecon1="GM12878", parFTRLreg=parFTRLreg)

write.table(round(output$TADs, digits=6), paste0("./out/TADs ",format(Sys.time(),"%d-%b-%Y %H.%M"),".out"), sep="\t", col.names=TRUE, row.names=FALSE)
write.table(round(output$R2, digits=6), paste0("./out/R2 ",format(Sys.time(),"%d-%b-%Y %H.%M"),".out"), sep="\t", col.names=FALSE, row.names=TRUE)

pvalue <- output$TADs[,"p-value"]
qvalue <- output$TADs[,"q-value"]
selbyp <- sum(pvalue[!is.na(pvalue)] < 0.05, na.rm=TRUE)
selbyq <- sum(qvalue[!is.na(qvalue)] < 0.05, na.rm=TRUE)
