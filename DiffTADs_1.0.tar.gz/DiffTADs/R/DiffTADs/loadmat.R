loadmat <- function(dirin1, dirin2)
{
  matlist  <- list()
  if(is.null(dirin1) == FALSE)
  {
    listcon1 <- sapply(list.files(dirin1, pattern=".txt", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
    listcon1 <- lapply(listcon1, as.matrix)
    namesplit <- strsplit(basename(names(listcon1)),split=".",fixed=TRUE)
    names(listcon1) <- unlist(lapply(namesplit,head,1)) 
    matlist[["listcon1"]] <- listcon1
  }
  if(is.null(dirin2) == FALSE)
  {
    listcon2 <- sapply(list.files(dirin2, pattern=".txt", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
    listcon2 <- lapply(listcon2, as.matrix)
    namesplit <- strsplit(basename(names(listcon2)),split=".",fixed=TRUE)
    names(listcon2) <- unlist(lapply(namesplit,head,1))
    matlist[["listcon2"]] <- listcon2
  }
  
  return(matlist)
}
