rm(list=ls())
setwd("E:/TADs/regevaluate")
source("regevaluate.R")

filein.y <- "E:/TADs/DiffTADs/out/y.out"
filein.p <- "E:/TADs/DiffTADs/out/p.out"
fileout <- "E:/TADs/DiffTADs/out/regevaluate.TIFF"
regevaluate(filein.y, filein.p, selrep=4, seliter=2, fileout)


