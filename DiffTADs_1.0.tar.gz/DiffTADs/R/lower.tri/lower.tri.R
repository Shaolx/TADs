lower.tri <- function(filein.y, filein.p, selrep, seliter)
{
  yvalue <- as.matrix(read.table(filein.y, header=F))
  pvalue <- as.matrix(read.table(filein.p, header=F))
  rowy <- nrow(yvalue)
  rowp <- nrow(pvalue)
  #print(dim(yvalue))
  #print(dim(pvalue))
  totalnum<-dim(yvalue)[2]
  #print(totalnum)
  originalval <- as.matrix(yvalue[selrep,])
  fittedval <- as.matrix(pvalue[seliter,])
  total<- nrow(fittedval)
  f<- function(x,a,b,c) a*x^2+b*x+c
  a<- 1
  b<- 1
  c<- (-2)*totalnum
  num<- uniroot(f, c(0,10000),a=a, b=b, c=c, tol=0.00001)
  num<- num$root
  print(num)
  tri<- matrix(0,nrow=num,ncol=num)
  n<- 1
  for (i in 1:num) 
  {
    for (j in 1:i) 
    {
      tri[i,j]<-fittedval[n,1]
      n<- n+1
    }
  }
  n<-1
  #tri<- tri+t(tri)
  for(j in 1:num){
    for(i in 1:j){
      tri[i,j]<-originalval[n,1]
      n<- n+1
    }
  }
  for (i in 1:num) 
  {
    tri[i,i]<-tri[i,i]/2  
  }
  return(tri)
}
