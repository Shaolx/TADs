
rm(list=ls())
source("E:/TADs/lower.tri/lower.tri.R")

filein.y<- "E:/TADs/DiffTADs/out/y.out"
filein.p<- "E:/TADs/DiffTADs/out/p.out"
selrep<- 4
seliter<- 2
tri <- lower.tri(filein.y, filein.p, selrep, seliter)

library(gplots)
library(pheatmap)
pheatmap(log(tri+1),col=colorpanel(128,"lightyellow","red"),border_color=NA,scale="none",cluster_rows=FALSE,cluster_cols=FALSE,show_rownames=FALSE,show_colnames=FALSE,fontsize=4)