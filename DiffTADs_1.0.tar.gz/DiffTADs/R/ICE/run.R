rm(list=ls())
setwd("E:/TADs/normalization/ICE")
source("sparse2matrix.R")
source("gethicobjlist.R")
source("normICEfun.R")
hicnormalized <- normICEfun(dirin="E:/TADs/dump/IMR90/chr1/50K", 
                            dirout="E:/TADs/HTADsPre/normdata/IMR90/chr1/50k/ICE", 
                            dirtemp="E:/TADs/normalization/data/temp", 
                            species="hg19", chr="chr1", resolution=50000)

hicnormalized <- normICEfun(dirin="E:/TADs/dump/IMR90/chr8/50K", 
                            dirout="E:/TADs/HTADsPre/normdata/IMR90/chr8/50k/ICE", 
                            dirtemp="E:/TADs/normalization/data/temp", 
                            species="hg19", chr="chr8", resolution=50000)

hicnormalized <- normICEfun(dirin="E:/TADs/dump/IMR90/chr14/50K", 
                            dirout="E:/TADs/HTADsPre/normdata/IMR90/chr14/50k/ICE", 
                            dirtemp="E:/TADs/normalization/data/temp", 
                            species="hg19", chr="chr14", resolution=50000)

hicnormalized <- normICEfun(dirin="E:/TADs/dump/IMR90/chr18/50K", 
                            dirout="E:/TADs/HTADsPre/normdata/IMR90/chr18/50k/ICE", 
                            dirtemp="E:/TADs/normalization/data/temp", 
                            species="hg19", chr="chr18", resolution=50000)
#hicnormalized <- normICEfun(dirin="../data/dump/GM12878/chr1/50K", dirout="../out/GM12878/chr1/50K/ICE", dirtemp="../data/temp", species="hg19", chr="chr1", resolution=50000)
#hicnormalized <- normICEfun(dirin="../data/dump/GM12878/chr1/25K", dirout="../out/GM12878/chr1/25K/ICE", dirtemp="../data/temp", species="hg19", chr="chr1", resolution=25000)