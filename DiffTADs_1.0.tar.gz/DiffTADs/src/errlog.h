#ifndef ERRLOG_H
#define ERRLOG_H

class Errlog
{
public:
	Errlog(void);
    ~Errlog(void);
public:
	void errlog(const char* errinfor);
};

#endif
