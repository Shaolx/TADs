#ifndef ICNORM_H
#define ICNORM_H

void normalizationbyic(double *psourdata, int width, int height, int maxiter, double experowsum, double *pdestdata);

#endif
